import { Component, OnInit } from '@angular/core';
import { BankserviceService } from '../bankservice.service';
import { PersonalInformation } from '../personalInformation';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  constructor(private service: BankserviceService) { }

  ngOnInit() {
  }

  personalInformation:PersonalInformation={
    customerId : 0,
    customerName: '',
    customerEmail: '',
    customerPassword: '',
    customerPhoneNumber:'',
    customerAddress:'',
    customerCity: '',
    customerCountry: '',
    customerZip: '',
    customerBalance: 0
  };



  onSubmit(){
    
    this.service.deposit(this.personalInformation.customerBalance).subscribe(
    data => { alert(data+ " rupees is the balance after depositing")});

      alert("Amount deposited successfully")
  }

}
