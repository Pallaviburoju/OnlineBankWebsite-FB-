package com.forms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.forms.dao.FormDao;
import com.forms.dao.TransactionDao;
import com.forms.model.PersonalInformation;
import com.forms.model.TransactionDetails;

@CrossOrigin(origins= "http://localhost:4200")
@RestController
public class Controller {

	@Autowired 
	private FormDao formDao;
	
	@Autowired
	private TransactionDao tDao;
	
	int custId;
	
	@GetMapping("/display")
	public String display() {
		return "Hello";
	}
	@PostMapping("/register")
	public int register(@RequestBody PersonalInformation cd) {
		formDao.register(cd);
		return formDao.register(cd).getCustomerId();
	} 
	
	@PostMapping("/login")
	public int login(@RequestBody PersonalInformation pi) {
		custId= formDao.login(pi);
		return formDao.login(pi);
		
	}
	
	
	@GetMapping("/showbalance")
	public int showBalance() {
		return tDao.showBalance(custId);
		
	}
	
	@PutMapping("/deposit")
	public int deposit(@RequestBody int amt) {
		int amount = 0;
		if(custId != 0) {
			amount = tDao.deposit(custId,amt);
		}
		return amount;
	}
	
    @PutMapping("/withdraw")
	public int withdraw(@RequestBody int amt) {
		int amount = 0;
		if(custId != 0) {
			amount = tDao.withdraw(custId,amt);
		}
		
		return amount;
		
	}
    
    @PutMapping("/fundtransfer")
	public int fundTransfer(@RequestBody TransactionDetails transaction) {
		
		if(custId != 0) {
			transaction = tDao.fundTransfer(custId,transaction);
			tDao.insertTransaction(transaction);
			return transaction.getTransactionId();
		}
		return transaction.getTransactionId();
	}
    
    @GetMapping("/getAll")
    public List<PersonalInformation> get() {
		return formDao.getData();
    }
    
    @DeleteMapping("/delete/{id}")
    public PersonalInformation deleteData(@PathVariable int id) {
		return formDao.deleteData(id);
    	
    }
}

