package com.forms.infofromangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.forms.dao")
@ComponentScan("com.forms.controller")
@ComponentScan("com.forms.model")
@EntityScan(basePackages = {"com.forms.model"})
@SpringBootApplication
public class FormsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormsApplication.class, args);
	}

}
