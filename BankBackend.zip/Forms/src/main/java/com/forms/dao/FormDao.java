package com.forms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;


import org.springframework.stereotype.Component;

import com.forms.model.PersonalInformation;

@Transactional
@Component("formDao")

public class FormDao{//can implement jpa repository also instead of entity manager
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	public PersonalInformation register(PersonalInformation pi) {
		// TODO Auto-generated method stub
		entityManager.persist(pi);
		return pi;
	}
	
	public int login(PersonalInformation pi) {
		// TODO Auto-generated method stub
		int custId = 0;
		//ApplicationContext context=new ClassPathXmlApplicationContext("hibernate.cfg.xml");		
		//entityManager.persist(c);
		PersonalInformation piFromDatabase = entityManager.find(PersonalInformation.class, pi.getCustomerId());
		if(piFromDatabase.getCustomerPassword().equals(pi.getCustomerPassword())) {
			custId = pi.getCustomerId(); 
			System.out.println("login successful");
		}
		
		return custId;
	}
	
	public List<PersonalInformation> getData() {
		Query query = entityManager.createQuery("from PersonalInformation");
		return query.getResultList();
		
	}
	
	public PersonalInformation deleteData(int custId){
//		Query query = entityManager.createQuery("delete from PersonalInformation where customer_id = :accountNumber");
//		query.setParameter("accountNumber", custId);
		
		PersonalInformation pi = entityManager.find(PersonalInformation.class, custId);
		entityManager.remove(pi);
		return pi;
		
	}
}
