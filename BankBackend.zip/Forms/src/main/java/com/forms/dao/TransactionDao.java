package com.forms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.forms.model.PersonalInformation;
import com.forms.model.TransactionDetails;

@Transactional
@Component("tDao")
public class TransactionDao {

	@PersistenceContext
	EntityManager entityManager;
	public int deposit(int custId, int amt) {
		// TODO Auto-generated method stub
		int amount = 0;
		PersonalInformation pi = entityManager.find(PersonalInformation.class, custId);
		amount = pi.getCustomerBalance()+amt;
		pi.setCustomerBalance(amount);
		Query query = entityManager.createQuery("update PersonalInformation set customer_balance = :balanceAmt where customer_id= :accountNumber");
		query.setParameter("balanceAmt", amount);
		query.setParameter("accountNumber", custId);
		query.executeUpdate();
		return amount;
	}
	
	public int withdraw(int custId, int amt) {
		// TODO Auto-generated method stub
		int amount = 0;
		PersonalInformation pi = entityManager.find(PersonalInformation.class, custId);
		if(pi.getCustomerBalance()>amt) {
			amount = pi.getCustomerBalance()-amt;
			pi.setCustomerBalance(amount);
			Query query = entityManager.createQuery("update PersonalInformation set customer_balance = :balanceAmt where customer_id= :accountNumber");
			query.setParameter("balanceAmt", amount);
			query.setParameter("accountNumber", custId);
			query.executeUpdate();
		}
		return amount;
	}
	

	public int showBalance(int custId) {
		// TODO Auto-generated method stub
		int amount = 0;
		PersonalInformation pi = entityManager.find(PersonalInformation.class, custId);
		amount = pi.getCustomerBalance();
		return amount;
	}

	public TransactionDetails fundTransfer(int custId, TransactionDetails transaction) {
		// TODO Auto-generated method stub
		int amount = 0;
		TransactionDetails td = null;
		PersonalInformation from = entityManager.find(PersonalInformation.class, custId);
		PersonalInformation to = entityManager.find(PersonalInformation.class, transaction.getToAcc());
		if(from.getCustomerBalance()>transaction.getAmt()) {
			amount = from.getCustomerBalance()-transaction.getAmt();
			from.setCustomerBalance(amount);
			int toAmt = to.getCustomerBalance()+transaction.getAmt();
			to.setCustomerBalance(toAmt);
			Query query = entityManager.createQuery("update PersonalInformation set customer_balance = :balanceAmt where customer_id= :accountNumber");
			query.setParameter("balanceAmt", amount);
			query.setParameter("accountNumber", custId);
			query.executeUpdate();
			query = entityManager.createQuery("update PersonalInformation set customer_balance = :balanceAmt where customer_id= :accountNumber");
			query.setParameter("balanceAmt", toAmt);
			query.setParameter("accountNumber", to.getCustomerId());
			query.executeUpdate();
			td = new TransactionDetails();
			td.setFromAcc(custId);
			td.setToAcc(transaction.getToAcc());
			td.setAmt(transaction.getAmt());
		}
		return td;
	}

	public boolean insertTransaction(TransactionDetails transaction) {
		// TODO Auto-generated method stub
		boolean isInserted = false;
		if(transaction.getAmt() != 0) {
			entityManager.persist(transaction);
			isInserted = true;
		}
		return isInserted;
	}
}

